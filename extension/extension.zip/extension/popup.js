async function downloadCertificate() {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();

  // Add Trophy Image
  const trophyImg = new Image();
  trophyImg.src = 'icons';
  await new Promise(resolve => { trophyImg.onload = resolve; trophyImg.onerror = resolve; });
  doc.addImage(trophyImg, 'PNG', 15, 20, 20, 20);

  // Add Certificate Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(22);
  doc.text("Certificate of Achievement", 40, 30);

  // Add Certificate Body
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(12);
  doc.text("This proudly certifies that", 20, 50);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(26);
  doc.setTextColor(212, 175, 55); // Gold color
  doc.text("YOU", 105, 70, null, null, 'center');
  doc.setTextColor(0, 0, 0); // Reset color to black

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(12);
  const text = "have demonstrated unparalleled dedication in the field of advanced procrastination by successfully wasting a full minute on the internet.";
  const splitText = doc.splitTextToSize(text, 170);
  doc.text(splitText, 20, 85);

  doc.text("You are now a distinguished recipient of the", 20, 115);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text("Golden Mouse Award for Digital Time Investment", 105, 130, null, null, 'center');


  // Add Signature
  doc.setFont('helvetica', 'italic');
  doc.setFontSize(12);
  doc.text("Sir Reginald Procrastinates-a-Lot", 55, 175, null, null, 'center');
  doc.line(20, 170, 90, 170); // x1, y1, x2, y2
  doc.setFontSize(10);
  doc.text("Grand Master of Digital Dalliance", 55, 180, null, null, 'center');

  const sealImg = new Image();
  sealImg.src = 'https://i.imgur.com/J8b4g3v.png';
  await new Promise(resolve => { sealImg.onload = resolve; sealImg.onerror = resolve; });
  doc.addImage(sealImg, 'PNG', 150, 150, 40, 40);

  // Add Date
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(150); // Grey color
  doc.text(`Issued on: ${new Date().toLocaleDateString()}`, 20, 200);


  // Save the PDF
  doc.save("Internet-Achievement-Certificate.pdf");
}