chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("certificateAlarm", { periodInMinutes: 1 });
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create("certificateAlarm", { periodInMinutes: 1 });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "certificateAlarm") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const activeTabTitle = tabs[0].title;

      // Store the active tab title
      chrome.storage.local.set({ activeTabTitle });

      // Show notification
     chrome.notifications.create({
    type: "basic",
    iconUrl: "icons/icon48.png",
    title: "🏆 Achievement Unlocked!",
    message: `You've wasted another minute on "${activeTabTitle}"!`,
    priority: 2
    });

      // Open certificate tab
      chrome.tabs.create({
        url: chrome.runtime.getURL("certificate.html")
      });
    });
  }
});
