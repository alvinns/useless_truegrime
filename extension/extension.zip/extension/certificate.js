// Certificate Interactive Features - certificate.js

// Easter egg - click the trophy 5 times for rainbow mode
let clickCount = 0;

// Wait for DOM to load
document.addEventListener('DOMContentLoaded', function() {
    // Trophy click easter egg
    const trophyIcon = document.querySelector('.trophy-icon');
    if (trophyIcon) {
        trophyIcon.addEventListener('click', function() {
            clickCount++;
            if (clickCount === 5) {
                const certificate = document.getElementById('certificate');
                if (certificate) {
                    certificate.classList.add('konami');
                    setTimeout(() => {
                        certificate.classList.remove('konami');
                        clickCount = 0;
                    }, 5000);
                }
            }
        });
    }

    // Add some interactive sparkle effects
    document.addEventListener('mousemove', function(e) {
        if (Math.random() > 0.98) {
            createSparkle(e.clientX, e.clientY);
        }
    });
});

// PDF Generation function with sarcastic content - LANDSCAPE
async function downloadCertificate() {
    try {
        const { jsPDF } = window.jspdf;
        // Create landscape PDF (279mm x 216mm)
        const doc = new jsPDF('landscape', 'mm', 'a4');

        // Add Trophy Image
        const trophyImg = new Image();
        trophyImg.src = 'icons/icon16.png';
        await new Promise((resolve, reject) => {
            trophyImg.onload = resolve;
            trophyImg.onerror = () => {
                console.warn('Trophy image not found, continuing without it...');
                resolve();
            };
        });
        
        // Only add image if it loaded successfully
        if (trophyImg.complete && trophyImg.naturalWidth > 0) {
            doc.addImage(trophyImg, 'PNG', 20, 15, 15, 15);
        }

        // Add Certificate Title
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(24);
        doc.text("Certificate of Extraordinary Ordinariness", 140, 25, null, null, 'center');

        // Add subtitle
        doc.setFont('helvetica', 'italic');
        doc.setFontSize(14);
        doc.text("This utterly impressive document is ceremoniously presented to", 140, 40, null, null, 'center');

        // Add recipient name
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(36);
        doc.setTextColor(255, 107, 107);
        doc.text("YOU", 140, 60, null, null, 'center');
        doc.setTextColor(0, 0, 0);

        // Add main sarcastic text
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(12);
        const mainText = "In recognition of your remarkable ability to successfully complete a task that required approximately the same level of skill as breathing while awake. Your dedication to spending precious minutes of your finite existence engaging with this magnificently pointless achievement truly demonstrates humanity's infinite capacity for finding meaning in the meaningless.";
        const splitMainText = doc.splitTextToSize(mainText, 220);
        doc.text(splitMainText, 140, 80, null, null, 'center');

        // Add authority statement
        doc.setFont('helvetica', 'italic');
        doc.setFontSize(11);
        doc.text("By the questionable authority vested in us by absolutely no one,", 140, 120, null, null, 'center');

        // Add award title
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(18);
        doc.setTextColor(255, 193, 7);
        doc.text("You are hereby awarded the Golden Waste of Time Medal", 140, 135, null, null, 'center');
        doc.setTextColor(0, 0, 0);

        // Add Signature Image
        const signatureImg = new Image();
        signatureImg.src = 'icons/signature.png';
        await new Promise((resolve, reject) => {
            signatureImg.onload = resolve;
            signatureImg.onerror = () => {
                console.warn('Signature image not found, using text fallback...');
                resolve();
            };
        });

        // Add signature (image or text fallback)
        if (signatureImg.complete && signatureImg.naturalWidth > 0) {
            doc.addImage(signatureImg, 'PNG', 40, 160, 50, 12);
        } else {
            doc.line(30, 170, 90, 170);
        }
        
        // Add signature details
        doc.setFont('helvetica', 'italic');
        doc.setFontSize(12);
        doc.text("Dr. Procrastination McTimeWaster", 65, 180, null, null, 'center');
        
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(9);
        doc.text("Chief Executive of Pointless Endeavors", 65, 185, null, null, 'center');
        doc.text("& Minister of Magnificent Futility", 65, 190, null, null, 'center');

        // Add Seal Image
        const sealImg = new Image();
        sealImg.src = 'icons/seal.png';
        await new Promise((resolve, reject) => {
            sealImg.onload = resolve;
            sealImg.onerror = () => {
                console.warn('Seal image not found, using text fallback...');
                resolve();
            };
        });
        
        // Add seal (image or text fallback)
        if (sealImg.complete && sealImg.naturalWidth > 0) {
            doc.addImage(sealImg, 'PNG', 200, 155, 35, 35);
        } else {
            doc.setFont('helvetica', 'bold');
            doc.setFontSize(10);
            doc.setTextColor(102, 126, 234);
            doc.circle(217.5, 172.5, 17.5);
            doc.text("CERTIFIED", 217.5, 170, null, null, 'center');
            doc.text("USELESS", 217.5, 176, null, null, 'center');
            doc.setTextColor(0, 0, 0);
        }

        // Add Date with sarcastic note
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(10);
        doc.setTextColor(150);
        const currentDate = new Date().toLocaleDateString();
        doc.text(`Certified on: ${currentDate}`, 25, 200);
        doc.text(`(A date you'll probably forget immediately)`, 25, 205);

        // Add a small disclaimer at the bottom
        doc.setFontSize(8);
        doc.setTextColor(100);
        doc.text("* This certificate has no actual value and is purely for entertainment purposes.", 140, 195, null, null, 'center');
        doc.text("** But hey, at least you got something for your time! 🎉", 140, 200, null, null, 'center');

        // Save the PDF with updated filename
        doc.save("Certificate-of-Extraordinary-Ordinariness.pdf");
        
        // Show a fun success message
        console.log('🎉 PDF generated successfully! Your certificate of uselessness is ready!');

    } catch (error) {
        console.error('Error generating certificate:', error);
        alert('🤔 Well, this is ironic... The certificate generator broke while trying to certify your achievement. How perfectly useless! Please try again.');
    }
}

// Sparkle creation function
function createSparkle(x, y) {
    const sparkle = document.createElement('div');
    sparkle.innerHTML = '✨';
    sparkle.style.position = 'fixed';
    sparkle.style.left = x + 'px';
    sparkle.style.top = y + 'px';
    sparkle.style.pointerEvents = 'none';
    sparkle.style.fontSize = '20px';
    sparkle.style.zIndex = '1000';
    sparkle.style.animation = 'sparkleFloat 2s ease-out forwards';
    document.body.appendChild(sparkle);
    
    setTimeout(() => {
        if (document.body.contains(sparkle)) {
            document.body.removeChild(sparkle);
        }
    }, 2000);
}

// Optional: Export functions if using modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        downloadCertificate,
        createSparkle
    };
}
